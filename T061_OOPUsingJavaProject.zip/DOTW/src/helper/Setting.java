package helper;

public interface Setting {
	final String monsterTxt = "monster.txt";
	final String userTxt = "credential.txt";
	final String itemTxt = "item.txt";

}
