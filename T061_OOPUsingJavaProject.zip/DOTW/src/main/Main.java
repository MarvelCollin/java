package main;

import java.util.Random;
import java.util.Scanner;

import game.Map;
import game.Player;
import helper.Helper;
import prettifier.Color;
import scene.Battle;

public class Main implements Helper{
	public Main() {
		app.init();;
	}

	public static void main(String[] args) {
		new Main();
	}

}
